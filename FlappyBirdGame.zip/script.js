
document.addEventListener('DOMContentLoaded', function() {
    const bird = document.getElementById('bird');
    const gameArea = document.getElementById('gameArea');
    let birdYPosition = 200;
    let gravity = 2;
    let gameRunning = false;
    let gap = 450;
    let score = 0;

    document.getElementById('startButton').addEventListener('click', function() {
        document.getElementById('startScreen').style.display = 'none';
        gameRunning = true;
        startGame();
    });

    function control(e) {
        if (e.keyCode === 32) {
            jump();
        }
    }

    function jump() {
        if (birdYPosition > 50) {
            birdYPosition -= 50;
        }
    }

    function generatePipes() {
        // Pipe generation logic
    }

    function startGame() {
        birdYPosition += gravity;
        bird.style.top = birdYPosition + 'px';
        if (gameRunning) {
            requestAnimationFrame(startGame);
        }
    }

    document.addEventListener('keyup', control);
});
